import copy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import cv2

class Q_Net(nn.Module):
	def __init__(self, opt):
		super(Q_Net, self).__init__()
		self.fc_width=200
		self.action_dim=6
		self.conv = nn.Sequential(
			nn.Conv2d(4, 32, 8, stride=4),
			nn.ReLU(),
			nn.Conv2d(32, 64, 4, stride=2),
			nn.ReLU(),
			nn.Conv2d(64, 64, 3, stride=1),
			nn.ReLU(),
			nn.Flatten())
		self.fc1 = nn.Linear(64 * 17 * 17, self.fc_width)
		#self.fc1 = nn.Linear(64 * 12 * 12, self.fc_width)
		self.fc2 = nn.Linear(self.fc_width, self.action_dim)

	def forward(self, obs):
		s = obs.float()/255 #convert to f32 and normalize before feeding to network
		s = self.conv(s)
		s = torch.relu(self.fc1(s))
		q = self.fc2(s)
		return q

class DeepQ_Agent(object):
	def __init__(self):
		self.dvc = 'cuda'
		self.action_dim = 6
		self.fc_width = 200
		self.q_net = Q_Net(self).to(self.dvc)
		# print("----------in Agent, q_net=",self.q_net)
		self.q_target = copy.deepcopy(self.q_net)
		# Freeze target networks with respect to optimizers (only update via polyak averaging)
		for p in self.q_target.parameters(): p.requires_grad = False
		
	def select_action(self, state, evaluate):
		with torch.no_grad():
			# print("------in Agent,state1=",state.shape)
			# print("------in Agent,state2=",state[0:3,:,:].shape)
			# np_array = state.detach().cpu().numpy()[0]
			# # 使用 OpenCV 保存为图像
			# image = cv2.imwrite('output333.jpg', np_array)
			state = state.unsqueeze(0).to(self.dvc)
			# p = 0.01 if evaluate else self.exp_noise # e-greedy = 0.01
			p = 0.01  # e-greedy = 0.01
			if np.random.rand() < p:
				return np.random.randint(0,self.action_dim)
			else:
				return self.q_net(state).argmax().item()
	def load(self,ExperimentName,index):
		self.q_net.load_state_dict(torch.load(f"./model/{ExperimentName}_{index}k.pth", map_location=self.dvc))
		self.q_target.load_state_dict(torch.load(f"./model/{ExperimentName}_{index}k.pth", map_location=self.dvc))
