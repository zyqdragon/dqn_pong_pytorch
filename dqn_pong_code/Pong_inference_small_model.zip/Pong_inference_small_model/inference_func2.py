import numpy as np
import torch
from Agent import DeepQ_Agent
from tianshou_wrappers import make_env_tianshou
import cv2

'''Hyperparameter Setting'''
opt_ModelIdex=600  # 600
opt_noop_reset=False
opt_seed=3
opt_algo_name='DQN'
opt_EnvName ="Pong"+ "NoFrameskip-v4"
opt_ExperimentName = opt_algo_name + '_' + opt_EnvName

def evaluate_policy(env, agent, seed, turns = 3):
    agent.q_net.eval() # 关闭NoisyNet的噪声
    scores = 0
    idx=0
    ik=0
    for j in range(turns):
        idx=idx+1
        print("------------------------------------------idx=",idx+1)
        s, info = env.reset(seed=seed)
        done = False
        with open('file.txt', 'w') as f:    
            while not done:
                ik=ik+1
                print("---------ik=",ik)
                # print("------in Agent,state1=",s.shape)
                print("------in Agent,state2=",s[0:1,:,:].shape)
                np_array0 = s[0:1,:,:].detach().cpu().numpy()[0]
                np_array1 = s[1:2,:,:].detach().cpu().numpy()[0]
                np_array2 = s[2:3,:,:].detach().cpu().numpy()[0]
                np_array3 = s[3:4,:,:].detach().cpu().numpy()[0]
                print("-----np_array0.shape=",np_array0.shape)
                # 使用 OpenCV 保存为图像
                image = cv2.imwrite('./status/s'+str(ik)+'_0.jpg', np_array0)
                image = cv2.imwrite('./status/s'+str(ik)+'_1.jpg', np_array1)
                image = cv2.imwrite('./status/s'+str(ik)+'_2.jpg', np_array2)
                image = cv2.imwrite('./status/s'+str(ik)+'_3.jpg', np_array3)
                a = agent.select_action(s, evaluate=True) # choose action with e-greedy = 0.01
                if a==0 or a==1:
                    at=0
                elif a==2  or a==4:
                    at=2
                elif a==3 or a==5:
                    at=3
                else:
                    print("-------wrong a value------------")

                s_next, r, dw, tr, info = env.step(a) # dw(dead & win): terminated, tr: truncated
                f.writelines("---------line"+str(ik)+"****reward="+str(r)+", action="+str(at)+"\n")
                done = (dw or tr)
                scores += r
                s = s_next
    # agent.q_net.train()
    return int(scores/turns)

def main():
    # Build evaluation env
    render_mode = 'human'
    eval_env = make_env_tianshou(opt_EnvName, noop_reset=opt_noop_reset, episode_life=False, clip_rewards=False, render_mode=render_mode)
    print("--------eval_env=",eval_env)
    print("--------eval_env=",eval_env.action_space)
    print("--------eval_env=",eval_env.observation_space)
    print("--------eval_env=",eval_env.observation_space.sample())

    agent = DeepQ_Agent()
    agent.load(opt_ExperimentName,opt_ModelIdex)    
    while True:
        score = evaluate_policy(eval_env, agent, seed=opt_seed, turns=1)
        print(opt_ExperimentName, 'seed:', opt_seed, 'score:', score)
    env.close()
    eval_env.close()

if __name__ == '__main__':
    main()