import numpy as np
import torch
from Agent import DeepQ_Agent, ReplayBuffer_torch
import os, shutil
from datetime import datetime
import argparse
from utils import evaluate_policy, str2bool, LinearSchedule
from tianshou_wrappers import make_env_tianshou
from AtariNames import Name

'''Hyperparameter Setting'''
parser = argparse.ArgumentParser()
opt_device='cuda'
opt_write=True
# opt_render=True
opt_render=False
opt_Loadmodel=False
opt_ModelIdex=600

opt_Max_train_steps=int(1E6)
opt_save_interval=int(1E5)
opt_eval_interval=int(5E3)
opt_random_steps=int(1e4)
opt_buffersize=int(1e4)
# opt_target_freq=int(1E3)

opt_lr=1e-4
opt_init_e=1.0
opt_anneal_frac=3e5
opt_final_e=0.02
opt_noop_reset=False

opt_EnvIdex=37
opt_seed=8

# opt = parser.parse_args()
opt = 8
# opt.dvc = torch.device(opt.device)
opt_dvc = 'cuda'  # cpu or cuda
# opt.algo_name = ('Double-' if opt.Double else '') + ('Duel-' if opt.Duel else '') + ('Noisy-' if opt.Noisy else '') + 'DQN'
opt_algo_name='DQN'
opt_EnvName = Name[opt_EnvIdex] + "NoFrameskip-v4"
opt_ExperimentName = opt_algo_name + '_' + opt_EnvName
print(opt)

def main():
    # Seed Everything
    np.random.seed(opt_seed)
    torch.manual_seed(opt_seed)
    torch.cuda.manual_seed(opt_seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Build evaluation env
    render_mode = 'human' if opt_render else None
    eval_env = make_env_tianshou(opt_EnvName, noop_reset=opt_noop_reset, episode_life=False, clip_rewards=False, render_mode=render_mode)
    print("--------eval_env=",eval_env)
    print("--------eval_env=",eval_env.action_space)
    print("--------eval_env=",eval_env.observation_space)
    print("--------eval_env=",eval_env.observation_space.sample())

    # opt.action_dim = eval_env.action_space.n
    opt_action_dim = 6
    print('Algorithm:',opt_algo_name,'  Env:',opt_EnvName,'  Action_dim:',opt_action_dim,'  Seed:',opt_seed, '\n')

    #Build Agent
    if not os.path.exists('model'): os.mkdir('model')
    agent = DeepQ_Agent(opt)
    if opt_Loadmodel: agent.load(opt_ExperimentName,opt_ModelIdex)

    opt_init_e=1.0

    if opt_render:
        while True:
            score = evaluate_policy(eval_env, agent, seed=opt_seed, turns=1)
            print(opt.ExperimentName, 'seed:', opt.seed, 'score:', score)
    else:
        if opt_write:
            from torch.utils.tensorboard import SummaryWriter
            timenow = str(datetime.now())[0:-7]
            timenow = ' ' + timenow[0:13] + '_' + timenow[14:16] + '_' + timenow[-2::]
            writepath = f'runs/{opt_ExperimentName}_S{opt_seed}' + timenow
            if os.path.exists(writepath): shutil.rmtree(writepath)
            writer = SummaryWriter(log_dir=writepath)

        # Build replay buffer and training env
        buffer = ReplayBuffer_torch(device=opt_dvc, max_size=opt_buffersize)
        env = make_env_tianshou(opt_EnvName, noop_reset = opt_noop_reset)

        #explore noise linearly annealed from 1.0 to 0.02 within anneal_frac steps
        schedualer = LinearSchedule(schedule_timesteps=opt_anneal_frac, final_p=opt_final_e, initial_p=opt_init_e)
        agent.exp_noise = opt_init_e
        seed = opt_seed

        total_steps = 0
        while total_steps < opt_Max_train_steps:
            s, info = env.reset(seed=seed)
            seed += 1 # 每次reset都使用新的seed,防止overfitting
            done = False
            while not done:
                a = agent.select_action(s, evaluate=False)
                s_next, r, dw, tr, info = env.step(a) # dw(dead & win): terminated; tr: truncated
                buffer.add(s, a, r, s_next, dw)
                done = dw + tr
                s = s_next

                # train, e-decay, log, save
                if buffer.size >= opt_random_steps:
                    agent.train(buffer)

                    '''record & log'''
                    if total_steps % opt_eval_interval == 0:
                        score = evaluate_policy(eval_env, agent, seed=seed+1) # 不与当前训练seed重合，更general
                        if opt_write:
                            writer.add_scalar('ep_r', score, global_step=total_steps)
                            # writer.add_scalar('noise', agent.exp_noise, global_step=total_steps)
                        print(f"{opt_ExperimentName}, Seed:{opt_seed}, Step:{int(total_steps/1000)}k, Score:{score}")
                        agent.exp_noise = schedualer.value(total_steps) # e-greedy decay

                    total_steps += 1
                    '''save model'''
                    if total_steps % opt_save_interval == 0:
                        agent.save(opt_ExperimentName,int(total_steps/1000))

    env.close()
    eval_env.close()

if __name__ == '__main__':
    main()