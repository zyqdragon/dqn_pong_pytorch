import torch.nn.functional as F
from torch import nn
import torch
import math

def evaluate_policy(env, agent, seed, turns = 3):
    agent.q_net.eval() # 关闭NoisyNet的噪声
    scores = 0
    for j in range(turns):
        s, info = env.reset(seed=seed)
        done = False
        while not done:
            a = agent.select_action(s, evaluate=True) # choose action with e-greedy = 0.01
            s_next, r, dw, tr, info = env.step(a) # dw(dead & win): terminated, tr: truncated
            done = (dw or tr)
            scores += r
            s = s_next
    agent.q_net.train()
    return int(scores/turns)

#You can just ignore this funciton. Is not related to the RL.
def str2bool(v):
    '''Fix the bool BUG for argparse: transfer string to bool'''
    if isinstance(v, bool): return v
    if v.lower() in ('yes', 'True','true','TRUE', 't', 'y', '1', 'T'): return True
    elif v.lower() in ('no', 'False','false','FALSE', 'f', 'n', '0', 'F'): return False
    else: print('Wrong Input Type!')