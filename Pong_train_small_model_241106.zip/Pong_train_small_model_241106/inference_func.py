import numpy as np
import torch
from Agent import DeepQ_Agent, ReplayBuffer_torch
import os, shutil
from datetime import datetime
import argparse
# from utils import evaluate_policy, str2bool, LinearSchedule
from utils import evaluate_policy, str2bool
from tianshou_wrappers import make_env_tianshou

'''Hyperparameter Setting'''
parser = argparse.ArgumentParser()
opt_device='cuda'
opt_write=True
# opt_render=True
opt_render=True
opt_Loadmodel=True
opt_ModelIdex=500  # 500

opt_Max_train_steps=int(1E6)
opt_save_interval=int(1E5)
opt_eval_interval=int(5E3)
opt_random_steps=int(1e4)
opt_buffersize=int(1e4)

opt_noop_reset=False
opt_seed=3
opt_dvc = 'cpu'  # cpu or cuda
opt_algo_name='DQN'
opt_EnvName ="Pong" + "NoFrameskip-v4"
opt_ExperimentName = opt_algo_name + '_' + opt_EnvName

def main():
    # Seed Everything
    np.random.seed(opt_seed)
    torch.manual_seed(opt_seed)
    torch.cuda.manual_seed(opt_seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Build evaluation env
    render_mode = 'human' if opt_render else None
    eval_env = make_env_tianshou(opt_EnvName, noop_reset=opt_noop_reset, episode_life=False, clip_rewards=False, render_mode=render_mode)
    print("--------eval_env=",eval_env)
    print("--------eval_env=",eval_env.action_space)
    print("--------eval_env=",eval_env.observation_space)
    print("--------eval_env=",eval_env.observation_space.sample())

    # opt.action_dim = eval_env.action_space.n
    opt_action_dim = 6
    print('Algorithm:',opt_algo_name,'  Env:',opt_EnvName,'  Action_dim:',opt_action_dim,'  Seed:',opt_seed, '\n')

    #Build Agent
    if not os.path.exists('model'): os.mkdir('model')
    agent = DeepQ_Agent()
    if opt_Loadmodel: agent.load(opt_ExperimentName,opt_ModelIdex)
    while True:
        print("------------------------------------------")
        score = evaluate_policy(eval_env, agent, seed=opt_seed, turns=1)
        print(opt_ExperimentName, 'seed:', opt_seed, 'score:', score)
    env.close()
    eval_env.close()

if __name__ == '__main__':
    main()